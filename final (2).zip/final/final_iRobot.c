/**
 * final_iRobot.c
 * @author Kevin Tran
 * date: 4/24/2025
 */




void iRobot_init() {
    uart_sendChar(128); // Start IO


}
